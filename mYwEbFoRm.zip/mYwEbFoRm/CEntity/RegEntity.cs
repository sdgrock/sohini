﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CEntity
{
    public class RegEntity
    {
        public string INSTITUTE_NAME { get; set; }
        public string COURSE_NAME { get; set; }
        public string STUDENT_NAME { get; set; }
        public DateTime DOB { get; set; }

        public int ADMISSION_ID { get; set; }
        public int STUDENT_ID { get; set; }
        public int COURSE_ID { get; set; }
        public int INSTITUTE_ID { get; set; }

       
    }
}
