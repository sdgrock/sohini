﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CDAL;
using CEntity;

namespace CBAL
{
    public class BALClass
    {
        public static List<RegEntity> getAllInstituteBAL()
        {
            return new DALClass().getAllInstitute();
        }
        public static List<RegEntity> getAllCourseBAL()
        {
            return new DALClass().getAllCourse();
        }
        public static bool AddAdmissionDAL(RegEntity aobj)
        {
            return new DALClass().AddAdmissionDAL(aobj);
        }
    }
}
