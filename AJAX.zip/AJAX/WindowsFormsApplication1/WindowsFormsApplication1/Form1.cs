﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private int getCount()
        {
            Thread.Sleep(5000);
            return 1000;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int count = getCount();
            label1.Text = "Done.......got" + count;
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            Task<int> task = new Task<int>(getCount);
            task.Start();
            label2.Text = "Loading...";
            int count = await task;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label3.Text = "Form is now responsive";
        }
    }
}
