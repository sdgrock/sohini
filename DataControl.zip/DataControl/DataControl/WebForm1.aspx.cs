﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DataControl
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
        {
            Label3.Text = "Productsof Category ID - "
                            + GridView2.SelectedValue
                            + ", Category Name - "
                            + GridView2.SelectedRow.Cells[2].Text;
        }
    }
}