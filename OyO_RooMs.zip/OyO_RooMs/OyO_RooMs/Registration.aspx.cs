﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CBal;
using CEntity;

namespace OyO_RooMs
{
    public partial class Registration1 : System.Web.UI.Page
    {
        int sum;
        protected void Page_Load(object sender, EventArgs e)
        {
          

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            EntityClass fobj = new EntityClass();
            fobj.CITY = DropDownList1.SelectedItem.Text;
            fobj.CUSTOMER_NAME = TextBox1.Text;
            fobj.ADDRESS = TextBox2.Text;
            fobj.DATE_IN = Convert.ToDateTime(TextBox4.Text);
            fobj.DATE_OUT = Convert.ToDateTime(TextBox3.Text);
            fobj.ID_DOC = DropDownList3.SelectedItem.Text;
            fobj.ROOM_TYPE = DropDownList2.SelectedItem.Text;

            bool result = BalClass.AddCustomerDAL(fobj);

            sum = (Convert.ToInt32(fobj.DATE_OUT.Day) - Convert.ToInt32(fobj.DATE_IN.Day)) * Convert.ToInt32(DropDownList2.SelectedItem.Value);

            if (result)
            {
                Label9.Text = "Registered";
            }
            else
                Label9.Text = "Not Registered";

            if (fobj.DATE_OUT.Day > fobj.DATE_IN.Day)
            {
                Label10.Text = "Your bill amount is : " + sum;
            }
            else
            {
                Label10.Text = "DateOut less than DateIn";
            }
            
        }
    }
}