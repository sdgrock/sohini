﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OyO_RooMs
{
    public partial class Login : System.Web.UI.Page
    {
        string username = "admin";
        string password = "admin";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (TextBox1.Text.Equals(username) && TextBox2.Text.Equals(password))
            {
                FormsAuthentication.RedirectFromLoginPage(TextBox1.Text, false);
            }
            else
            {
                Label4.Text = "Login credentials do not match";
            }
        }
    }
}