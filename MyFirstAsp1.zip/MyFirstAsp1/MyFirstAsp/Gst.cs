﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyFirstAsp
{
    public class Gst
    {
        public string SlabName { get; set; }
        public int TaxRate { get; set; }
    }
}