﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentWebEntity
{
    public class Admission
    {
        private int _admissionid;
        private DateTime _admissiondate;

        public int Admissionid
        {
            get
            {
                return _admissionid;
            }

            set
            {
                _admissionid = value;
            }
        }

        public DateTime Admissiondate
        {
            get
            {
                return _admissiondate;
            }

            set
            {
                _admissiondate = value;
            }
        }
        public Admission()
        {

        }
    }
}
