﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentWebEntity
{
    public class Institute
    {
        private int _instituteid;
        private string _institutename;
        private string _city;

        public int Instituteid
        {
            get
            {
                return _instituteid;
            }

            set
            {
                _instituteid = value;
            }
        }

        public string Institutename
        {
            get
            {
                return _institutename;
            }

            set
            {
                _institutename = value;
            }
        }

        public string City
        {
            get
            {
                return _city;
            }

            set
            {
                _city = value;
            }
        }
        public Institute()
        {

        }
    }
}
