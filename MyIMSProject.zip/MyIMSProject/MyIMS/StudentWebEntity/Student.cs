﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentWebEntity
{
    public class Student
    {
        private int _studentid;
        private string _studentname;
        private DateTime _dateofbirth;

        public int Studentid
        {
            get
            {
                return _studentid;
            }

            set
            {
                _studentid = value;
            }
        }

        public string Studentname
        {
            get
            {
                return _studentname;
            }

            set
            {
                _studentname = value;
            }
        }

        public DateTime Dateofbirth
        {
            get
            {
                return _dateofbirth;
            }

            set
            {
                _dateofbirth = value;
            }
        }

        public Student()
        {

        }
    }
}
