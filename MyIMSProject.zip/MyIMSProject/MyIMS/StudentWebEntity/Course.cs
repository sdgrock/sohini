﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentWebEntity
{
    public class Course
    {
        private int _courseid;
        private string _coursename;

        public int Courseid
        {
            get
            {
                return _courseid;
            }

            set
            {
                _courseid = value;
            }
        }

        public string Coursename
        {
            get
            {
                return _coursename;
            }

            set
            {
                _coursename = value;
            }
        }
        public Course()
        {

        }
    }
}
