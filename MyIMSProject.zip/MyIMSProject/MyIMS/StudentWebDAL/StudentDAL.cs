﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StudentWebEntity;
using StudentWebException;
using System.Data.Common;
using System.Data;


namespace StudentWebDAL
{
    public class StudentDAL
    {
        public bool AddStudentDAL(Student entobj)
        {
            bool studAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                //PROCEDURE NAME
                command.CommandText = "AddStudentweb";


                //NAME
                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ipv_studentname";
                param.DbType = DbType.String;
                param.Value = entobj.Studentname;
                command.Parameters.Add(param);

                //DOB
                param = command.CreateParameter();
                param.ParameterName = "@ipv_dateofbirth";
                param.DbType = DbType.DateTime;
                param.Value = entobj.Dateofbirth;
                command.Parameters.Add(param);


                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    studAdded = true;
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new StudentException(errormessage);
            }
            return studAdded;

        }


        public bool AddInstituteDAL(Institute entobj)
        {
            bool instAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                //PROCEDURE NAME
                command.CommandText = "addInstitute";


                //CITY
                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ipv_institutename";
                param.DbType = DbType.String;
                param.Value = entobj.Institutename;
                command.Parameters.Add(param);

                //NAME
                param = command.CreateParameter();
                param.ParameterName = "@ipv_city";
                param.DbType = DbType.String;
                param.Value = entobj.City;
                command.Parameters.Add(param);


                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    instAdded = true;
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new StudentException(errormessage);
            }
            return instAdded;

        }



        public bool AddCourseDAL(Course entobj)
        {
            bool cAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                //PROCEDURE NAME
                command.CommandText = "addCourse";


                //NAME
                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ipv_coursename";
                param.DbType = DbType.String;
                param.Value = entobj.Coursename;
                command.Parameters.Add(param);




                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    cAdded = true;
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new StudentException(errormessage);
            }
            return cAdded;

        }



        public bool AddAdmissionDAL(string cname, string instname, Admission aobj)
        {
            bool admisAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                //PROCEDURE NAME
                command.CommandText = "addAdmission";


                //COURSE
                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ipv_Coursename";
                param.DbType = DbType.String;
                param.Value = cname;
                command.Parameters.Add(param);

                //INSTITUTE
                param = command.CreateParameter();
                param.ParameterName = "@ipv_Institutename";
                param.DbType = DbType.String;
                param.Value = instname;
                command.Parameters.Add(param);


                //ADMISSION DATE
                param = command.CreateParameter();
                param.ParameterName = "@ipv_admissiondate";
                param.DbType = DbType.DateTime;
                param.Value = aobj.Admissiondate;
                command.Parameters.Add(param);


                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    admisAdded = true;
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new StudentException(errormessage);
            }
            return admisAdded;

        }
    }
}
