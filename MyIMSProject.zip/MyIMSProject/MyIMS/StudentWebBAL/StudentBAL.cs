﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StudentWebDAL;
using StudentWebEntity;
using StudentWebException;


namespace StudentWebBAL
{
    public class StudentBAL
    {
        public static bool AddStudentBL(Student entobj)
        {
            bool studAdded = false;
            try
            {

                StudentDAL dal = new StudentDAL();
                studAdded = dal.AddStudentDAL(entobj);
                
            }
            catch (StudentException ex)
            {
                throw new StudentException(ex.Message);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return studAdded;
        }

        public static bool AddInstituteBL(Institute entobj)
        {
            bool instAdded = false;
            try
            {
                StudentDAL dal = new StudentDAL();
                instAdded = dal.AddInstituteDAL(entobj);
            }
            catch (StudentException ex)
            {
                throw new StudentException(ex.Message);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return instAdded;
        }



        public static bool AddCourseBL(Course entobj)
        {
            bool cAdded = false;
            try
            {
                StudentDAL dal = new StudentDAL();
                cAdded = dal.AddCourseDAL(entobj);
            }
            catch (StudentException ex)
            {
                throw new StudentException(ex.Message);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return cAdded;
        }

    }
}
