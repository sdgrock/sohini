﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using StudentWebBAL;
using StudentWebEntity;
using StudentWebDAL;
using StudentWebException;


namespace MyIMS
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                Admission adobj = new Admission();
                Institute iobj = new Institute();
                Student stdobj = new Student();
                Course cobj = new Course();
                
                stdobj.Studentname = TextBox1.Text;
                stdobj.Dateofbirth = Convert.ToDateTime(TextBox2.Text);
                
                iobj.City = TextBox3.Text;
                iobj.Institutename = TextBox4.Text;
                string instname = iobj.Institutename;
                
                cobj.Coursename = TextBox5.Text;
                string cname = cobj.Coursename;
                
                adobj.Admissiondate = Convert.ToDateTime(TextBox6.Text);





                StudentBAL.AddStudentBL(stdobj);
                StudentBAL.AddInstituteBL(iobj);
                StudentBAL.AddCourseBL(cobj);

                StudentDAL dal = new StudentDAL();
                dal.AddAdmissionDAL(cname, instname, adobj);



                Label8.Text = "Added Successfully";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
    }
}