﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using LoginEntity;
using LoginBAL;
using LoginDAL;
namespace Demo
{
    public partial class LoginForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            string username = TextBox1.Text;
            string password = TextBox2.Text;
            LoginEnt loginobj = new LoginEnt();
            loginobj.Username = username;
            loginobj.Password = password;
            LBal balobj = new LBal();
            bool status = balobj.LoginStatus(loginobj);
            bool status1 = balobj.LoginStatus1(username,password);
            if(status1 || status)
            {
                Label3.Text = "Succesfully Logged In";
                Label3.ForeColor = System.Drawing.Color.Green;
            }
            else
            {
                Label3.Text = "Try Again !!";
                Label3.ForeColor = System.Drawing.Color.Red;
            }
        }
    }
}