﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LoginEntity;
namespace LoginDAL
{
    public class LDal
    {
        public bool LoginValidation(LoginEnt entobj)
        {
            bool status = false;
                if((entobj.Username=="admin") && (entobj.Password=="admin"))
            {
                status = true;
            }

            return status;
        }
        public bool LoginValidation1(string Username, string Password)
        {
            bool status = false;
            if ((Username == "admin") && (Password == "admin"))
            {
                status = true;
            }

            return status;
        }

        }
    }
