﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LoginEntity;
using LoginDAL;
namespace LoginBAL
{
    public class LBal
    {
        public bool LoginStatus(LoginEnt lent)
        {
            LDal dalobj = new LDal();
            bool status = false;
            status = dalobj.LoginValidation(lent);
            return status;
        }
        public bool LoginStatus1(string username, string password)
        {
            LDal dalobj = new LDal();
            bool status = false;
            status = dalobj.LoginValidation1(username, password);
            return status;
        }

    }
}
