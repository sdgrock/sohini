﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CDal
{
    public class DalClass
    {
        public bool LoginValidation1(string Username, string Password)
        {
            bool status = false;
            if ((Username == "admin") && (Password == "admin"))
            {
                status = true;
            }

            return status;
        }
    }
}
