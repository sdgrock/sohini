﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CEntity
{
    public class EntityClass
    {
        private string _username;
        private string _password;

        private string policyName;
        private int policyid;
        private int duration;
        private int premAmt;
        private int matAmt;
        private int brnchid;
        private string brnchname;
        private string brnchadrs;
        private int custid;
        private string custname;
        private string address;
        private DateTime dob;


        public string Username
        {
            get { return _username; }
            set { _username = value; }
        }

        public string Password
        {
            get { return _password; }
            set { _password = value; }
        }

        public string Policy_Name 
        { 
            get { return policyName; }
            set { policyName = value; } 
        }

        public int Policy_Id
        {
            get { return policyid; }
            set { policyid = value; }
        }

        public int Duration
        {
            get { return duration; }
            set { duration = value; }
        }

        public int Premium_Amt
        {
            get { return premAmt; }
            set { premAmt = value; }
        }

        public int Matured_Amount
        {
            get { return matAmt; }
            set { matAmt = value; }
        }

        public int Branch_Id
        {
            get { return brnchid; }
            set { brnchid = value; }
        }

        public string Branch_Name
        {
            get { return brnchname; }
            set { brnchname = value; }
        }

        public string Branch_Address
        {
            get { return brnchadrs; }
            set { brnchadrs = value; }
        }

        public int Customer_Id
        {
            get { return custid; }
            set { custid = value; }
        }

        public string Customer_Name
        {
            get { return custname; }
            set { custname = value; }
        }

        public string Address
        {
            get { return address; }
            set { address = value; }
        }

        public DateTime DOB
        {
            get { return dob; }
            set { dob = value; }
        }
    }
}
