﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CEntity;
using CBal;

namespace LICProj
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsign_Click(object sender, EventArgs e)
        {
            string username = txtname.Text;
            string password = textpw.Text;
            EntityClass loginobj = new EntityClass();
            loginobj.Username = username;
            loginobj.Password = password;
            BalClass balobj = new BalClass();           
            bool status1 = balobj.LoginStatus1(username, password);
            if (status1)
            {
                //Label5.Text = "Succesfully Logged In";
                //Label5.ForeColor = System.Drawing.Color.Green;

                Response.Redirect("WebForm2.aspx");
            }
            else
            {
                Label5.Text = "Wrong Username or Password !!";
                Label5.ForeColor = System.Drawing.Color.Red;
            }
            
        }
    }
}