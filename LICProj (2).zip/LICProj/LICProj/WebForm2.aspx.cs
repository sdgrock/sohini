﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CBal;
using CEntity;

namespace LICProj
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnreg_Click(object sender, EventArgs e)
        {
            if ((DropDownList1.SelectedIndex>0)&&(DropDownList2.SelectedIndex>0))
            {
                Label7.Text = "Registered";
                Label7.ForeColor = System.Drawing.Color.Green;
            }
            else
            {
                Label7.Text = "Try Again !!";
                Label7.ForeColor = System.Drawing.Color.Red;
            }

        }
    }
}