﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CDal;
using CEntity;

namespace CBal
{
    public class BalClass
    {
        public bool LoginStatus1(string username, string password)
        {
            DalClass dalobj = new DalClass();
            bool status = false;
            status = dalobj.LoginValidation1(username, password);
            return status;
        }
    }
}
