﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MyFirstAsp
{
    public partial class ASPday1p2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string mail = "";
            string prod = "";
            if(!Page.IsPostBack)
            {
                if(Request.QueryString.Count == 2)
                {
                    prod = Request.QueryString[0];
                    mail = Request.QueryString[1];
                }
                Label1.Text = "Thanks for Purchasing"
                    + prod +
                    ", you will get an email on your email-id - "
                    + mail;
            }
        }
    }
}