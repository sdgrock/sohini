﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

namespace MyFirstAsp
{
    public partial class ASPday1p1 : System.Web.UI.Page
    {
        List<Gst> gstList = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            //Label1.Text = "Label on load";
            if (!Page.IsPostBack)
            {
                //Label1.Text = "Before going to Server";
                gstList = new List<Gst>
                {
                    new Gst { SlabName = "Food Items", TaxRate = 5 },
                    new Gst { SlabName = "Electronics Items", TaxRate = 12 },
                    new Gst { SlabName = "Automobiles Items", TaxRate = 18 }
                };
                DropDownList1.Items.Clear();
                DropDownList1.Items.Add(new ListItem("Select a Slab", "0"));
                DropDownList1.AppendDataBoundItems = true;
                DropDownList1.DataSource = gstList;
                DropDownList1.DataTextField = "Slabname";
                DropDownList1.DataValueField = "TaxRate";
                DropDownList1.DataBind();
            }

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList2.Items.Clear();
            DropDownList2.Items.Add("SELECT A PRODUCT");
            switch(Convert.ToInt32(DropDownList1.SelectedItem.Value))
            {
                case 12:
                    DropDownList2.Items.Add("LED TV");
                    DropDownList2.Items.Add("LAPTOP");
                    DropDownList2.Items.Add("MOBILE");
                    break;

                case 5:
                    DropDownList2.Items.Add("PIZZA");
                    DropDownList2.Items.Add("BURGER");
                    DropDownList2.Items.Add("COFFEE");
                    break;

                case 18:
                    DropDownList2.Items.Add("CAR");
                    DropDownList2.Items.Add("BUS");
                    DropDownList2.Items.Add("TRAIN");
                    break;

            }
        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            Double taxrate = Convert.ToDouble(
            DropDownList1.SelectedItem.Value                      
        );
            Double gstAmount = 0.0;
            gstAmount = Convert.ToDouble(TextBox1.Text) +
                (Convert.ToDouble(TextBox1.Text) * taxrate) / 100;

            Label1.Text = DropDownList2.SelectedItem.Text + "(" + DropDownList1.SelectedItem.Text + ")" + " purchased for amount -" + gstAmount.ToString();
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("ASPday1p2.aspx");
        }

        protected void btnCart_Click(object sender, EventArgs e)
        {
            Response.Redirect("ASPday1p2.aspx?prod=" 
                + DropDownList2.SelectedItem.Text 
                + "&email=" + TextBox2.Text);
        }
        //else
        //{
        //     Label1.Text = "Info from Server";
        //}
    }
}
       

        //protected void btnsubmit_Click(object sender, EventArgs e)
        //{
        //// Label1.Text = "Welcome to ASP.NET";
    
        //}

        //protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        //{
        ////Label1.Text = DropDownList1.Text + " - "
        //// + DropDownList1.SelectedItem ;   
        ////Label1.Text = DropDownList1.SelectedItem.Value + " - " + DropDownList1.SelectedItem.Text;  
                   
        //}
    //}
//}