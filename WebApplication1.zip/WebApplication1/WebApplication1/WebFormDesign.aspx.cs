﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

namespace WebApplication1
{
    public partial class WebFormDesign : System.Web.UI.Page
    {
        //ArrayList arraylist1 = new ArrayList();
        //ArrayList arraylist2 = new ArrayList();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            ListItem obj = new ListItem();
            obj.Text = TextBox1.Text;
            if (!(ListBox1.Items.Contains(obj)))
            {
                ListBox1.Items.Add(obj);
            } 
            else
            {
                Label1.Text = "Please select an item to add";
            }     
                          
        }



        //Function which will call two methods (simpler code)
        private void addRemove(ListBox ListBox1, ListBox ListBox2)
        {
            if (ListBox1.SelectedIndex != -1)
            {
                foreach (ListItem li in ListBox1.Items)
                {
                    if (li.Selected)
                    {
                        ListBox2.Items.Add(li);
                    }
                }

                foreach (ListItem li in ListBox2.Items)
                {
                    ListBox1.Items.Remove(li.Value);
                }
                Label1.Text = "";
                ListBox2.ClearSelection();
            }
            else
            {
                Label1.Text = "Please select atleast one item";
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            //move all the items from one listbox to other 

            //while (ListBox1.Items.Count != 0)
            //{
            //    for (int i = 0; i < ListBox1.Items.Count; i++)
            //    {
            //        ListBox2.Items.Add(ListBox1.Items[i]);
            //        ListBox1.Items.Remove(ListBox1.Items[i]);
            //    }
            //}

            //move single item from one listbox to other

            //ListBox2.Items.Add(ListBox1.SelectedItem);

            //move multiple items from one listbox to other

            //    Label1.Visible = false;
            //    if (ListBox1.SelectedIndex >= 0)
            //    {
            //        for (int i = 0; i < ListBox1.Items.Count; i++)
            //        {
            //            if (ListBox1.Items[i].Selected)
            //            {
            //                if (!arraylist1.Contains(ListBox1.Items[i]))
            //                {
            //                    arraylist1.Add(ListBox1.Items[i]);
            //                }
            //            }
            //        }
            //        for (int i = 0; i < arraylist1.Count; i++)
            //        {
            //            if (!ListBox2.Items.Contains(((ListItem)arraylist1[i])))
            //            {
            //                ListBox2.Items.Add(((ListItem)arraylist1[i]));
            //            }
            //            ListBox1.Items.Remove(((ListItem)arraylist1[i]));
            //        }
            //        ListBox2.SelectedIndex = -1;
            //    }
            //    else
            //    {
            //        Label1.Visible = true;
            //        Label1.Text = "Please select atleast one in Listbox1 to move";
            //    }



            //Method calling
            addRemove(ListBox1, ListBox2);

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            //move all the items from second listbox to first

            //while (ListBox2.Items.Count != 0)
            //{
            //    for (int i = 0; i < ListBox2.Items.Count; i++)
            //    {
            //        ListBox1.Items.Add(ListBox2.Items[i]);
            //        ListBox2.Items.Remove(ListBox2.Items[i]);
            //    }
            //}

            //move single item from second listbox to first

            //ListBox1.Items.Add(ListBox2.SelectedItem);

            //move multiple items from one listbox to other

            //Label1.Visible = false;
            //if (ListBox2.SelectedIndex >= 0)
            //{
            //    for (int i = 0; i < ListBox2.Items.Count; i++)
            //    {
            //        if (ListBox2.Items[i].Selected)
            //        {
            //            if (!arraylist2.Contains(ListBox2.Items[i]))
            //            {
            //                arraylist2.Add(ListBox2.Items[i]);
            //            }
            //        }
            //    }
            //    for (int i = 0; i < arraylist2.Count; i++)
            //    {
            //        if (!ListBox1.Items.Contains(((ListItem)arraylist2[i])))
            //        {
            //            ListBox1.Items.Add(((ListItem)arraylist2[i]));
            //        }
            //        ListBox2.Items.Remove(((ListItem)arraylist2[i]));
            //    }
            //    ListBox1.SelectedIndex = -1;
            //}
            //else
            //{
            //    Label1.Visible = true;
            //    Label1.Text = "Please select atleast one in Listbox2 to move";
            //}



            //Method calling
            addRemove(ListBox2, ListBox1);

        }
    }
}