﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;
using System.Data;
using CEntity;
using System.Data.SqlClient;

namespace CDal
{
    public class DalClass
    {
        public bool AddCustDAL(EntityClass newCust, string policy, string branch)
        {
            bool guestAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "AddCust";
                DbParameter param = command.CreateParameter();

                param.ParameterName = "@custID";
                param.DbType = DbType.Int32;
                param.Direction = ParameterDirection.Output;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@custName";
                param.DbType = DbType.String;
                param.Value = newCust.CustomerName;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@dob";
                param.DbType = DbType.Date;
                param.Value = newCust.DOB;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@address";
                param.DbType = DbType.String;
                param.Value = newCust.Address;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@policyName";
                param.DbType = DbType.String;
                param.Value = policy;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@branchName";
                param.DbType = DbType.String;
                param.Value = branch;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    guestAdded = true;
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw;// new GuestPhoneBookException(errormessage);
            }
            return guestAdded;

        }
        public List<string> GetPolicyList()
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=Training;Integrated Security=True");
            SqlCommand com;
            List<string> policyList = new List<string>();
            try
            {
                con.Open();
                com = new SqlCommand();
                com.Connection = con;
                com.CommandType = CommandType.Text;
                com.CommandText = "select polname from Policy";
                DataTable dt = null;
                SqlDataReader dr = com.ExecuteReader();
                dt = new DataTable();
                dt.Load(dr);

                for (int row = 0; row < dt.Rows.Count; row++)
                {
                    string policy = dt.Rows[row][0].ToString();
                    policyList.Add(policy);
                }

            }
            catch (DbException ex)
            {
                throw;
            }
            return policyList;
        }
        public List<string> GetBranchList()
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=Training;Integrated Security=True");
            SqlCommand com = new SqlCommand();
            List<string> bankList = new List<string>();
            con.Open();
            com.Connection = con;
            com.CommandType = CommandType.Text;
            com.CommandText = "select branchname from Branch";
            DataTable dt = new DataTable();
            SqlDataReader dr = com.ExecuteReader();
            dt.Load(dr);
            for (int row = 0; row < dt.Rows.Count; row++)
            {
                string branch = dt.Rows[row][0].ToString();
                bankList.Add(branch);
            }
            return bankList;
        }
    }
}
