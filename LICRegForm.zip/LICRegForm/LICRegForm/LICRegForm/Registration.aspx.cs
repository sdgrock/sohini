﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CDal;
using CEntity;

namespace LICRegForm
{
    public partial class Registration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            DalClass dalobj = new DalClass();
            List<string> policyList = dalobj.GetPolicyList();
            List<string> branchList = dalobj.GetBranchList();
            DropDownList1.DataSource = policyList;
            DropDownList1.DataBind();
            DropDownList2.DataSource = branchList;
            DropDownList2.DataBind();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            EntityClass newCust = new EntityClass();

            newCust.CustomerName = TextBox2.Text;
            newCust.DOB = Convert.ToDateTime(TextBox3.Text);
            newCust.Address = TextBox4.Text;

            DalClass dalobj = new DalClass();
            if (dalobj.AddCustDAL(newCust, DropDownList1.SelectedItem.Text, DropDownList2.SelectedItem.Text))
                Label7.Text = "Customer Added";
            else
                Label7.Text = "Customer not added";
        }
    }
}